package vms;

import java.util.InputMismatchException;
import java.util.Scanner;
import vaccine.Vaccines;
import patient.PatientDetails;

public class Menu {
    private VaccineManagementSystem vms;
    private Utilities utilities;

    public Menu(VaccineManagementSystem vms, Utilities utilities) {
        this.vms = vms;
        this.utilities = utilities;
    }

    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice = -1;

        do {
            try {
                // Display menu
                System.out.println("\r\n" +
                        "  ___ __  __ __  __ _   _ _   _ ___ _____   _  _____ ___ ___  _   _   _____ ____      _    ____ _  _______ ____    __  __ _____ _   _ _   _ \r\n" +
                        " |_ _|  \\/  |  \\/  | | | | \\ | |_ _|__  /  / \\|_   _|_ _/ _ \\| \\ | | |_   _|  _ \\    / \\  / ___| |/ / ____|  _ \\  |  \\/  | ____| \\ | | | | |\r\n" +
                        "  | || |\\/| | |\\/| | | | |  \\| || |  / /  / _ \\ | |  | | | | |  \\| |   | | | |_) |  / _ \\| |   | ' /|  _| | |_) | | |\\/| |  _| |  \\| | | | |\r\n" +
                        "  | || |  | | |  | | |_| | |\\  || | / /_ / ___ \\| |  | | |_| | |\\  |   | | |  _ <  / ___ \\ |___| . \\| |___|  _ <  | |  | | |___| |\\  | |_| |\r\n" +
                        " |___|_|  |_|_|  |_|\\___/|_| \\_|___/____/_/   \\_\\_| |___\\___/|_| \\_|   |_| |_| \\_\\/_/   \\_\\____|_|\\_\\_____|_| \\_\\ |_|  |_|_____|_| \\_|\\___/ \r\n" +
                        "                                                                                                                                            \r\n" +
                        "");
                System.out.println("\t[1] Display Vaccines");
                System.out.println("\t[2] Add New Patient");
                System.out.println("\t[3] Display all Patients");
                System.out.println("\t[4] Edit Patient");
                System.out.println("\t[5] Exit");
                System.out.print("\tEnter your choice: ");

                // Handle invalid input for menu choice
                while (!scanner.hasNextInt()) {
                    System.err.println("Invalid input. Please enter a numeric value for your choice.");
                    scanner.next(); // Clear invalid input
                }
                choice = scanner.nextInt();
                scanner.nextLine(); // Clear newline character

                if (choice < 1 || choice > 5) {
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                    continue; // Skip the rest of the loop and prompt again
                }

                // Switch case to handle different menu choices
                switch (choice) {
                    case 1:
                        utilities.delay(500);
                        Vaccines.displayVaccineVault();
                        System.out.println("Press enter to continue...");
                        scanner.nextLine(); // Wait for user input before continuing
                        utilities.clearScreen();
                        break;
                    case 2:
                        utilities.delay(1000);
                        vms.addPatient();
                        System.out.println("Press enter to continue...");
                        scanner.nextLine();
                        utilities.clearScreen();
                        break;
                    case 3:

                        vms.displayAllPatients();
                        break;
                    case 4:
                        vms.displayAllPatients();
                        System.out.print("\nEnter the Patient ID to edit or view record: ");
                        String patientID = scanner.nextLine();
                        PatientDetails patient = vms.findPatientByID(patientID);

                        if (patient == null) {
                            System.out.println("Patient with ID " + patientID + " not found. Please try again.");
                        } else {
                            System.out.println("Selected Patient: " + patient.getFirstName() + " " + patient.getLastName());
                            utilities.delay(500);
                            vms.patientMenu(patient);
                        }
                        break;
                    case 5:
                        System.out.println("Exiting Vaccine Management System.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                }
            } catch (InputMismatchException e) {
                // Handle invalid input type (non-integer input)
                System.err.println("Invalid input. Please enter a numeric value for your choice.");
                scanner.nextLine(); // Clear invalid input
            }  catch (Exception e) {
                // Catch-all for other unexpected exceptions
                System.err.println("An unexpected error occurred: " + e.getMessage());
            }
        } while (choice != 5);

        // Close the scanner after the loop ends
        scanner.close();
    }
}
